#!/bin/bash
# =============================================================
# preparar_pc.sh - Deja PC2, PC3 o PC5 listos para la Sesion 2 (estacion 3).
# Uso:  sudo bash preparar_pc.sh PC2    (o PC3, o PC5)
# Requiere que R1 ya tenga su configuracion base (para salir a Internet).
# =============================================================
PC="${1:-}"
NIC=$(nmcli -t -f DEVICE,TYPE device | awk -F: '$2=="ethernet"{print $1; exit}')
CON=$(nmcli -g UUID,TYPE con show | awk -F: '$2=="802-3-ethernet"{print $1; exit}')
fija() { nmcli con mod "$CON" ipv4.method manual ipv4.addresses "$1/24" ipv4.gateway "$2" ipv4.dns "148.201.3.9 148.201.3.10" ipv6.method disabled; nmcli con up "$CON" >/dev/null; }
case "$PC" in
  PC2) fija 10.3.20.10 10.3.20.1
       apt-get update -qq && apt-get install -y nginx openssh-server nmap nftables fail2ban >/dev/null
       echo "<h1>Intranet - Estacion 3</h1>" > /var/www/html/index.html
       id prueba >/dev/null 2>&1 || useradd -m -s /bin/bash prueba; echo 'prueba:iteso' | chpasswd ;;
  PC3) fija 10.3.30.10 10.3.30.1
       apt-get update -qq && apt-get install -y nginx openssh-server ufw >/dev/null
       echo "<h1>Sitio web - Estacion 3</h1>" > /var/www/html/index.html ;;
  PC5) nmcli con mod "$CON" ipv4.method auto ipv4.addresses "" ipv4.gateway "" ipv4.dns "" ; nmcli con up "$CON" >/dev/null
       apt-get update -qq && apt-get install -y nmap curl screen >/dev/null ;;
  *) echo "Uso: sudo bash preparar_pc.sh PC2|PC3|PC5"; exit 1 ;;
esac
systemctl enable --now nginx ssh 2>/dev/null
echo; ip -br addr show "$NIC"; echo ">>> $PC listo."
