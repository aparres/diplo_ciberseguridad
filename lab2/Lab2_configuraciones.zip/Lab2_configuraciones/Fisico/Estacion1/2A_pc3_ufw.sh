#!/bin/bash
# Sesion 2 - Lab 2A - Firewall de HOST en PC3 (sitio web) con ufw, estacion 1
sudo ufw --force reset
sudo ufw default deny incoming                       # todo lo que entra, negado...
sudo ufw default allow outgoing                      # ...lo que sale, permitido
sudo ufw allow 80/tcp                                # ...excepto la web, para todos
sudo ufw allow from 10.1.20.10 to any port 22 proto tcp   # ...y SSH solo desde PC2
sudo ufw logging on
sudo ufw --force enable
sudo ufw status verbose
