#!/bin/bash
# =============================================================
# Diplomado en Ciberseguridad ITESO - Modulo 3 Herramientas
# pegar.sh - Carga un archivo de configuracion a un equipo Cisco
# por el cable de consola, linea por linea (sustituye al "pegar" de PuTTY).
#
# Uso:   1) Salgan de screen (Ctrl+A y luego K): el puerto serie debe quedar libre.
#        2) sudo bash pegar.sh 0_R1_base.txt
#           Si el equipo ya pide usuario (admin / iteso):
#           sudo bash pegar.sh --login 2B_R1_zbf.txt
#        3) Al terminar, entren con: sudo screen /dev/ttyS4 9600  y revisen: show running-config
# El puerto casi siempre es /dev/ttyS4. Para revisarlo: sudo dmesg | grep ttyS
# Opcional: ultimo argumento con otro puerto, por ejemplo /dev/ttyS0.
# =============================================================
LOGIN=0; [ "${1:-}" = "--login" ] && { LOGIN=1; shift; }
ARCH="${1:-}"; PUERTO="${2:-/dev/ttyS4}"
[ -r "$ARCH" ] || { echo "No encuentro el archivo: $ARCH"; exit 1; }
[ -e "$PUERTO" ] || { echo "No existe el puerto $PUERTO (revisen con: sudo dmesg | grep ttyS)"; exit 1; }
if fuser "$PUERTO" >/dev/null 2>&1; then echo "El puerto $PUERTO esta ocupado: salgan de screen (Ctrl+A y luego K) y repitan."; exit 1; fi
stty -F "$PUERTO" 9600 cs8 -cstopb -parenb -crtscts -ixon raw -echo || exit 1
exec 3<>"$PUERTO"
cat <&3 & LECTOR=$!
trap 'kill $LECTOR 2>/dev/null' EXIT
enviar() { printf '%s\r' "$1" >&3; }
echo ">>> Despertando el equipo..."
if [ $LOGIN = 1 ]; then
  enviar ""; sleep 2; enviar "admin"; sleep 2; enviar "iteso"; sleep 3      # usuario y contrasena
  enviar "enable"; sleep 2; enviar "iteso"; sleep 2                         # contrasena de enable
else
  enviar ""; sleep 2; enviar "no"; sleep 3; enviar ""; sleep 2              # por si aparece el dialogo inicial
  enviar "enable"; sleep 1
fi
enviar "configure terminal"; sleep 1
TOTAL=$(grep -cv '^\s*\(!\|$\)' "$ARCH"); I=0
while IFS= read -r L || [ -n "$L" ]; do
  L="${L%$'\r'}"
  case "$L" in ''|'!'*) continue ;; esac
  I=$((I+1)); enviar "$L"
  case "$L" in
    *"crypto key generate"*) sleep 25 ;;
    "write memory"|"copy running-config startup-config") sleep 10 ;;
    *) sleep 0.5 ;;
  esac
done < "$ARCH"
sleep 3
echo; echo ">>> Listo: se enviaron $I lineas de $ARCH."
echo ">>> Entren con: sudo screen $PUERTO 9600   y revisen con: show running-config"
